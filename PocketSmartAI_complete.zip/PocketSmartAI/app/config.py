import os
from dotenv import load_dotenv

load_dotenv()

class Settings:
    APP_NAME = os.getenv("APP_NAME", "PocketSmart AI")
    SECRET_KEY = os.getenv("SECRET_KEY", "change-this-secret-key")
    GEMINI_API_KEY = os.getenv("GEMINI_API_KEY", "")
    GEMINI_MODEL = os.getenv("GEMINI_MODEL", "gemini-1.5-flash")
    USE_MOCK_AI = os.getenv("USE_MOCK_AI", "false").lower() == "true"
    DATABASE_URL = os.getenv("DATABASE_URL", "sqlite:///./pocketsmart.db")
    HOST = os.getenv("HOST", "127.0.0.1")
    PORT = int(os.getenv("PORT", "8000"))
    MAX_UPLOAD_MB = int(os.getenv("MAX_UPLOAD_MB", "5"))

settings = Settings()
