# The documentation explicitly permits mock/simulated sourcing for Amazon,
# IKEA, Zomato, Swiggy, OYO, Flipkart, etc. This module provides deterministic
# demo catalog data so the application works without partner API credentials.

CATALOG = {
    "home": [
        {"name": "LED Ceiling Light", "platform": "Amazon", "price": 1499, "category": "Lighting"},
        {"name": "Minimalist Floor Lamp", "platform": "IKEA", "price": 2499, "category": "Lighting"},
        {"name": "Compact Study Table", "platform": "IKEA", "price": 5999, "category": "Furniture"},
        {"name": "Modern Dining Chair", "platform": "Amazon", "price": 1899, "category": "Furniture"},
        {"name": "Decorative Wall Art Set", "platform": "Amazon", "price": 1299, "category": "Decor"},
        {"name": "Storage Cabinet", "platform": "IKEA", "price": 7499, "category": "Storage"},
    ],
    "party": [
        {"name": "Vegetarian Catering Package", "platform": "Zomato", "price": 350, "unit": "per guest", "category": "Food"},
        {"name": "Party Food Package", "platform": "Swiggy", "price": 400, "unit": "per guest", "category": "Food"},
        {"name": "Budget Event Venue", "platform": "OYO", "price": 8000, "unit": "package", "category": "Venue"},
        {"name": "Basic Decoration Package", "platform": "Local Vendor", "price": 5000, "unit": "package", "category": "Decoration"},
    ],
    "jewelry": [
        {"name": "Pearl Drop Earrings", "platform": "Amazon", "price": 899, "category": "Earrings"},
        {"name": "Gold-Tone Necklace Set", "platform": "Flipkart", "price": 1799, "category": "Necklace"},
        {"name": "Minimal Bracelet", "platform": "Amazon", "price": 699, "category": "Bracelet"},
        {"name": "Statement Necklace", "platform": "Flipkart", "price": 2499, "category": "Necklace"},
        {"name": "Classic Jhumka Earrings", "platform": "Amazon", "price": 1199, "category": "Earrings"},
    ],
}

def get_catalog(kind):
    return CATALOG[kind]
