import json
import base64
from app.config import settings
from app.services.mock_catalog import get_catalog

try:
    import google.generativeai as genai
except ImportError:
    genai = None

def _mock_response(kind, data):
    budget = float(data["budget"])
    catalog = get_catalog(kind)
    candidates = [x for x in catalog if x["price"] <= budget]
    if kind == "party":
        guests = int(data["guests"])
        candidates = [
            {**x, "estimated_total": round(x["price"] * guests if x.get("unit") == "per guest" else x["price"], 2)}
            for x in candidates
        ]
    return {
        "planner": kind,
        "budget": budget,
        "source_mode": "mock",
        "summary": "Demo recommendations generated locally. Add a Gemini API key to enable AI-generated recommendations.",
        "budget_breakdown": _breakdown(kind, budget),
        "recommendations": candidates[:5],
        "notes": [
            "Prices are illustrative demo values.",
            "Verify current price, stock, delivery, and availability on the selected platform."
        ]
    }

def _breakdown(kind, budget):
    if kind == "home":
        parts = [("Furniture", .45), ("Lighting", .20), ("Decor", .15), ("Storage", .20)]
    elif kind == "party":
        parts = [("Food", .45), ("Venue", .25), ("Decoration", .20), ("Entertainment", .10)]
    else:
        parts = [("Primary jewelry", .60), ("Secondary jewelry", .25), ("Accessories", .15)]
    return [{"category": k, "amount": round(budget * p, 2), "percentage": int(p*100)} for k, p in parts]

def _prompt(kind, data, catalog):
    return f"""
You are PocketSmart AI, a budget-aware recommendation assistant.
Planner: {kind}
User input:
{json.dumps(data, indent=2)}
Demo catalog/platform context:
{json.dumps(catalog, indent=2)}

Generate practical recommendations that stay within the user's total budget.
Use only platforms represented in the supplied catalog when naming a platform.
Do not claim live prices or availability.
Return ONLY valid JSON with this shape:
{{
  "summary": "short summary",
  "budget_breakdown": [
    {{"category":"...", "amount":0, "percentage":0}}
  ],
  "recommendations": [
    {{"name":"...", "platform":"...", "estimated_price":0, "category":"...", "reason":"..."}}
  ],
  "notes": ["..."]
}}
"""

def _extract_json(text):
    text = text.strip()
    if text.startswith("```"):
        text = text.split("\n", 1)[1]
        text = text.rsplit("```", 1)[0]
    return json.loads(text)

def generate_recommendation(kind, data, image_bytes=None, image_mime=None):
    if settings.USE_MOCK_AI or not settings.GEMINI_API_KEY or genai is None:
        return _mock_response(kind, data)

    genai.configure(api_key=settings.GEMINI_API_KEY)
    model = genai.GenerativeModel(settings.GEMINI_MODEL)
    prompt = _prompt(kind, data, get_catalog(kind))
    content = [prompt]

    if image_bytes:
        content.append({
            "mime_type": image_mime or "image/jpeg",
            "data": base64.b64encode(image_bytes).decode("utf-8")
        })

    try:
        result = model.generate_content(content)
        parsed = _extract_json(result.text)
        parsed["planner"] = kind
        parsed["budget"] = float(data["budget"])
        parsed["source_mode"] = "gemini"
        return parsed
    except Exception as exc:
        fallback = _mock_response(kind, data)
        fallback["notes"].insert(0, f"Gemini call failed; fallback used: {type(exc).__name__}")
        return fallback
