from fastapi import FastAPI
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
from app.database import init_db
from app.routes.auth import router as auth_router
from app.routes.planners import router as planner_router
from app.routes.pages import router as pages_router
from app.routes.history import router as history_router
from app.config import settings

app = FastAPI(title="PocketSmart AI", version="1.0.0")

app.mount("/static", StaticFiles(directory="app/static"), name="static")
templates = Jinja2Templates(directory="app/templates")

app.include_router(pages_router)
app.include_router(auth_router, prefix="/api")
app.include_router(planner_router, prefix="/api")
app.include_router(history_router, prefix="/api")

@app.on_event("startup")
def startup():
    init_db()

@app.get("/health")
def health():
    return {"status": "ok", "app": "PocketSmart AI"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("app.main:app", host=settings.HOST, port=settings.PORT, reload=True)
