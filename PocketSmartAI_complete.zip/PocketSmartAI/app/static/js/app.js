const $ = (s) => document.querySelector(s);

async function api(url, options={}) {
  const res = await fetch(url, {credentials:"same-origin", ...options});
  const data = await res.json().catch(() => ({}));
  if (!res.ok) throw new Error(data.detail || data.message || "Request failed");
  return data;
}

function showResults(data) {
  const el = $("#results");
  if (!el) return;
  const breakdown = (data.budget_breakdown || []).map(x =>
    `<div class="break"><span>${x.category}</span><b>₹${Number(x.amount).toLocaleString()}</b><small>${x.percentage}%</small></div>`
  ).join("");
  const recs = (data.recommendations || []).map(x =>
    `<article class="rec"><h3>${x.name}</h3><span class="tag">${x.platform || "Suggested"}</span><p>${x.category || ""}</p><strong>₹${Number(x.estimated_price ?? x.price ?? x.estimated_total ?? 0).toLocaleString()}</strong><p>${x.reason || ""}</p></article>`
  ).join("");
  el.innerHTML = `<div class="card"><h2>${data.summary || "Recommendations"}</h2><p>Mode: <b>${data.source_mode}</b></p><h3>Budget allocation</h3>${breakdown}</div><div class="grid three">${recs}</div><div class="card"><h3>Notes</h3><ul>${(data.notes||[]).map(n=>`<li>${n}</li>`).join("")}</ul></div>`;
}

async function loadSession() {
  try {
    const d = await api("/api/session-info");
    const link = $("#loginLink"), logout = $("#logoutBtn");
    if (link) link.classList.add("hidden");
    if (logout) logout.classList.remove("hidden");
    const userBox = $("#dashboardUser");
    if (userBox) userBox.innerHTML = `<h3>Hello, ${d.user.name}</h3><p>${d.user.email}</p>`;
  } catch {}
}

$("#logoutBtn")?.addEventListener("click", async () => {
  await api("/api/logout", {method:"POST"});
  location.href="/login";
});

$("#registerForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    await api("/api/register", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(Object.fromEntries(f))});
    location.href="/login";
  } catch(err) { $("#message").textContent = err.message; }
});

$("#loginForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  try {
    await api("/api/login", {method:"POST", headers:{"Content-Type":"application/json"}, body:JSON.stringify(Object.fromEntries(f))});
    location.href="/dashboard";
  } catch(err) { $("#message").textContent = err.message; }
});

$("#homeForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const data = Object.fromEntries(f);
  data.budget = Number(data.budget);
  data.rooms = f.getAll("rooms");
  try { showResults(await api("/api/generate-home", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)})); }
  catch(err) { $("#results").innerHTML = `<div class="error">${err.message}</div>`; }
});

$("#partyForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  const data = Object.fromEntries(f);
  data.budget = Number(data.budget); data.guests = Number(data.guests);
  try { showResults(await api("/api/generate-party", {method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify(data)})); }
  catch(err) { $("#results").innerHTML = `<div class="error">${err.message}</div>`; }
});

$("#jewelryForm")?.addEventListener("submit", async e => {
  e.preventDefault();
  const f = new FormData(e.target);
  try { showResults(await api("/api/generate-jewelry", {method:"POST",body:f})); }
  catch(err) { $("#results").innerHTML = `<div class="error">${err.message}</div>`; }
});

async function loadHistory() {
  const el = $("#historyList"); if (!el) return;
  try {
    const rows = await api("/api/history");
    if (!rows.length) { el.innerHTML = `<div class="card">No recommendations yet.</div>`; return; }
    el.innerHTML = rows.map(r => `<div class="card history"><h3>${r.planner_type.toUpperCase()}</h3><p>${r.created_at}</p><p>Budget: ₹${Number(r.request.budget).toLocaleString()}</p><p>${r.response.summary || ""}</p></div>`).join("");
  } catch(err) { el.innerHTML = `<div class="error">${err.message}</div>`; }
}

loadSession();
loadHistory();
