from typing import Optional, List
from pydantic import BaseModel, Field, EmailStr

class RegisterRequest(BaseModel):
    name: str = Field(min_length=2, max_length=80)
    email: EmailStr
    password: str = Field(min_length=6, max_length=128)

class LoginRequest(BaseModel):
    email: EmailStr
    password: str

class HomeRequest(BaseModel):
    budget: float = Field(gt=0)
    rooms: List[str] = []
    style: str = "Modern"
    requirements: str = ""
    quantities: str = ""

class PartyRequest(BaseModel):
    budget: float = Field(gt=0)
    guests: int = Field(gt=0, le=10000)
    event_type: str = "Birthday"
    venue: str = ""
    preferences: str = ""

class JewelryRequest(BaseModel):
    budget: float = Field(gt=0)
    occasion: str = "Wedding"
    style: str = "Elegant"
    outfit_color: str = ""
    preferences: str = ""
