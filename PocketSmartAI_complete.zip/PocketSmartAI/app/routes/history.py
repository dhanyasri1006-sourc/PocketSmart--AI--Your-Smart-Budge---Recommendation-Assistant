import json
from fastapi import APIRouter, Request
from app.security import get_current_user
from app.database import get_db

router = APIRouter(tags=["History"])

@router.get("/history")
def history(request: Request):
    user = get_current_user(request)
    conn = get_db()
    rows = conn.execute(
        "SELECT id,planner_type,request_json,response_json,created_at FROM history WHERE user_id=? ORDER BY id DESC",
        (user["id"],)
    ).fetchall()
    conn.close()
    return [{
        "id": r["id"],
        "planner_type": r["planner_type"],
        "request": json.loads(r["request_json"]),
        "response": json.loads(r["response_json"]),
        "created_at": r["created_at"]
    } for r in rows]

@router.delete("/history/{history_id}")
def delete_history(history_id: int, request: Request):
    user = get_current_user(request)
    conn = get_db()
    cur = conn.execute("DELETE FROM history WHERE id=? AND user_id=?", (history_id, user["id"]))
    conn.commit()
    conn.close()
    return {"deleted": cur.rowcount == 1}
