import json
from fastapi import APIRouter, Request, UploadFile, File, Form, HTTPException
from app.models.schemas import HomeRequest, PartyRequest, JewelryRequest
from app.security import get_current_user
from app.services.gemini_service import generate_recommendation
from app.database import get_db

router = APIRouter(tags=["Planners"])

def save_history(user_id, kind, request_data, response_data):
    conn = get_db()
    conn.execute(
        "INSERT INTO history(user_id,planner_type,request_json,response_json) VALUES(?,?,?,?)",
        (user_id, kind, json.dumps(request_data), json.dumps(response_data))
    )
    conn.commit()
    conn.close()

@router.post("/generate-home")
def generate_home(data: HomeRequest, request: Request):
    user = get_current_user(request)
    result = generate_recommendation("home", data.model_dump())
    save_history(user["id"], "home", data.model_dump(), result)
    return result

@router.post("/generate-party")
def generate_party(data: PartyRequest, request: Request):
    user = get_current_user(request)
    result = generate_recommendation("party", data.model_dump())
    save_history(user["id"], "party", data.model_dump(), result)
    return result

@router.post("/generate-jewelry")
async def generate_jewelry(
    request: Request,
    budget: float = Form(...),
    occasion: str = Form("Wedding"),
    style: str = Form("Elegant"),
    outfit_color: str = Form(""),
    preferences: str = Form(""),
    outfit_image: UploadFile | None = File(None),
):
    user = get_current_user(request)
    if budget <= 0:
        raise HTTPException(400, "Budget must be greater than zero")
    image_bytes = None
    image_mime = None
    if outfit_image and outfit_image.filename:
        allowed = {"image/jpeg", "image/png", "image/webp"}
        if outfit_image.content_type not in allowed:
            raise HTTPException(400, "Only JPG, PNG, or WEBP images are supported")
        image_bytes = await outfit_image.read()
        if len(image_bytes) > 5 * 1024 * 1024:
            raise HTTPException(400, "Image must be 5 MB or smaller")
        image_mime = outfit_image.content_type

    data = {
        "budget": budget, "occasion": occasion, "style": style,
        "outfit_color": outfit_color, "preferences": preferences,
        "image_uploaded": bool(image_bytes)
    }
    result = generate_recommendation("jewelry", data, image_bytes, image_mime)
    save_history(user["id"], "jewelry", data, result)
    return result
