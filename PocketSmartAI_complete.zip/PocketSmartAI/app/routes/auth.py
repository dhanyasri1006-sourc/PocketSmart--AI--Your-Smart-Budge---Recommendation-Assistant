from fastapi import APIRouter, HTTPException, Response, Request
from app.models.schemas import RegisterRequest, LoginRequest
from app.database import get_db
from app.security import hash_password, verify_password, create_token, get_current_user

router = APIRouter(tags=["Authentication"])

@router.post("/register")
def register(data: RegisterRequest):
    conn = get_db()
    try:
        cur = conn.execute(
            "INSERT INTO users(name,email,password_hash) VALUES(?,?,?)",
            (data.name.strip(), data.email.lower(), hash_password(data.password))
        )
        conn.commit()
        return {"message": "Registration successful", "user_id": cur.lastrowid}
    except Exception as exc:
        if "UNIQUE" in str(exc).upper():
            raise HTTPException(409, "Email already registered")
        raise HTTPException(500, "Registration failed")
    finally:
        conn.close()

@router.post("/login")
def login(data: LoginRequest, response: Response):
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE email=?", (data.email.lower(),)).fetchone()
    conn.close()
    if not user or not verify_password(data.password, user["password_hash"]):
        raise HTTPException(401, "Invalid email or password")
    token = create_token(user["id"], user["email"])
    response.set_cookie("access_token", token, httponly=True, samesite="lax", max_age=43200)
    return {"message": "Login successful", "user": {"id": user["id"], "name": user["name"], "email": user["email"]}}

@router.post("/logout")
def logout(response: Response):
    response.delete_cookie("access_token")
    return {"message": "Logged out"}

@router.post("/token")
def token(data: LoginRequest):
    conn = get_db()
    user = conn.execute("SELECT * FROM users WHERE email=?", (data.email.lower(),)).fetchone()
    conn.close()
    if not user or not verify_password(data.password, user["password_hash"]):
        raise HTTPException(401, "Invalid credentials")
    return {"access_token": create_token(user["id"], user["email"]), "token_type": "bearer"}

@router.get("/session-info")
def session_info(request: Request):
    user = get_current_user(request)
    conn = get_db()
    row = conn.execute("SELECT id,name,email,created_at FROM users WHERE id=?", (user["id"],)).fetchone()
    conn.close()
    return {"logged_in": True, "user": dict(row)}

@router.get("/session-data")
def session_data(request: Request):
    user = get_current_user(request)
    conn = get_db()
    count = conn.execute("SELECT COUNT(*) FROM history WHERE user_id=?", (user["id"],)).fetchone()[0]
    conn.close()
    return {"user_id": user["id"], "recommendation_count": count}
